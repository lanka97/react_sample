import logo from './logo.svg';
import './App.css';
import CustomTextField from './components/CustomTextField';
import MainPage from './pages/MainPage';
import { QueryClient, QueryClientProvider } from "react-query";

var queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div>
        <MainPage />
      </div>
    </QueryClientProvider>
    // <div className="App">
    //   <header className="App-header">
    //     <img src={logo} className="App-logo" alt="logo" />
    //     <CustomTextField label="input"/>
    //   </header>
    // </div>
  );
}

export default App;
