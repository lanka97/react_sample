import React from 'react';
import './CustomDatepicker.css'; // Optional for custom styling

const CustomDatepicker = ({ label, selectedDate, onDateChange }) => {
    return (
        <div className="custom-datepicker">
            {label && <label>{label}</label>}
            <input
                type="date"
                value={selectedDate}
                onChange={(e) => onDateChange(e.target.value)}
            />
        </div>
    );
};

export default CustomDatepicker;
