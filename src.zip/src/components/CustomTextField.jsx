import React, { useState } from 'react';
import './CustomTextField.css';

const CustomTextField = ({ label, value, onChange, validate, errorText }) => {
    const [touched, setTouched] = useState(false);

    const handleBlur = () => {
        setTouched(true);
    };

    const isValid = validate ? validate(value) : true;

    return (
        <div className="custom-text-field">
            {label && <label>{label}</label>}
            <input
                type="text"
                value={value}
                onChange={onChange}
                onBlur={handleBlur}
                className={isValid ? '' : 'invalid'}
            />
            {touched && !isValid && <span className="error-text">{errorText}</span>}
        </div>
    );
};

export default CustomTextField;
