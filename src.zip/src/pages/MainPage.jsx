import React, { useState } from 'react';
import CustomDatepicker from '../components/CustomDatepicker'
import CustomTable from '../components/CustomTable'

const MainPage = ({ label, value, onChange, validate, errorText }) => {
    const columns = [
        { key: "emp_name", label:"Employee Name"},
        { key: "clientIds", label:"# of Client IDs w/Hours"},
        { key: "total_scheduled_id", label:"Total Scheduled Hours"},
        { key: "total_ot_eligible", label:"Total OT Eligible"},
        { key: "total_ot", label:"Total OT"}
    ]

    const data = [
        {
            emp_name: "Employee Name",
            clientIds: ["1"],
            total_scheduled_id: "55",
            total_ot_eligible: "55",
            total_ot: "55"
        }
    ]

    return (
        <div style={{ padding: 25 }}>
            <div style={{ width: "25%" }}>
                <CustomDatepicker label="input" onDateChange={()=>{}}/>
            </div>

            <h1>Data Table</h1>
            <CustomTable columns={columns} data={data} />
        </div>

    );
};

export default MainPage;
