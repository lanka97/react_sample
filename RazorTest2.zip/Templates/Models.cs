﻿public class ScreenConfig
{
    public string ScreenName { get; set; }
    public List<Component> Components { get; set; }
    public List<OnLoadApiCall> OnLoadApiCalls { get; set; }
    public Dictionary<string, string> ApiBindings { get; set; }

    public List<UseStates> UseStates { get; set; }
}

public class Component
{
    public string Type { get; set; }
    public Dictionary<string, string> Props { get; set; }
}

public class OnLoadApiCall
{
    public string Url { get; set; }
    public string Method { get; set; }
    public Payload Payload { get; set; }
    public string AssotiatedState { get; set; }
}
public class Payload
{
    public string PathParam { get; set; }
    public Dictionary<string, object> Body { get; set; }
}

public class UseStates
{
    public string Name { get; set; }

    public string Setter { get; set; }
    public string InitVal { get; set; }
}