﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using Newtonsoft.Json;
using RazorLight;

namespace CodeGenerator
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            // Read JSON configuration
            var jsonConfig = File.ReadAllText("Templates/screenConfig.json");
            var config = JsonConvert.DeserializeObject<ScreenConfig>(jsonConfig);

            // Get the directory of the executing assembly
            var projectDirectory = Directory.GetCurrentDirectory();

            // Initialize RazorLight engine
            var razorEngine = new RazorLightEngineBuilder()
                .UseFileSystemProject(projectDirectory) // Use file system project
                .UseMemoryCachingProvider()
                .Build();

            // Specify the path to the Razor template file
            var templatePath = Path.Combine(projectDirectory, "Templates/ReactTemplate.cshtml");

            // Generate React code using Razor template
            var result = await razorEngine.CompileRenderAsync(templatePath, config);

            // Save generated code to a file
            File.WriteAllText("test-app/src/pages/GeneratedReactComponent.jsx", result);

            Console.WriteLine("React component generated successfully!");


            // Stop the stopwatch
            stopwatch.Stop();

            // Get the elapsed time in seconds
            double elapsedSeconds = stopwatch.Elapsed.TotalSeconds;

            // Output the elapsed time
            Console.WriteLine($"Time taken: {elapsedSeconds} seconds");
        }
    }
}

/*
 limitetions 
    * Have to find a better way to handle imports
    * custom useEffects
    * create custome varibles (maybe we can add a extra section)
    * complex layouts (Not impossible but hard to plan ahead )
    * should update template for nested components  
 */